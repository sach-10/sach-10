# College Event Management Portal - Complete Guide

## 📋 Project Overview

A complete web-based portal for managing college events with the following features:
- **Event Announcements**: Display upcoming events with dates and venues
- **Online Registration**: Students can register for events through a form
- **Participant Management**: View all registered participants in a table

---

## 🏗️ Project Structure

```
CollegeEventManagement/
│
├── src/                                    # Source Code Directory
│   └── com/eventmanagement/
│       ├── servlet/
│       │   └── EventRegisterServlet.java   # Handles registration submissions
│       └── db/
│           └── DBConnection.java           # Database connection manager
│
├── WebContent/                             # Web Resources
│   ├── css/
│   │   └── style.css                       # Styling for all pages
│   ├── WEB-INF/
│   │   └── web.xml                         # Servlet configuration
│   ├── index.jsp                           # Home page with event listings
│   ├── register.jsp                        # Event registration form
│   └── participants.jsp                    # Display registered participants
│
└── database/
    └── schema.sql                          # Database creation script
```

---

## 🛠️ Technology Stack

| Component | Technology |
|-----------|-----------|
| Frontend | HTML5, CSS3 |
| Backend | Java Servlets, JSP |
| Server | Apache Tomcat |
| Database | MySQL |
| Connectivity | JDBC (MySQL Connector/J) |
| Architecture | MVC (Model-View-Controller) |

---

## 📊 Database Schema

### Database: `eventdb`

#### Table: `participants`
```sql
CREATE TABLE participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    usn VARCHAR(20) NOT NULL,
    event VARCHAR(100) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Columns Description:**
- `id`: Unique identifier for each registration (auto-incremented)
- `name`: Student's full name
- `usn`: University Seat Number (student ID)
- `event`: Name of the event student registered for
- `registration_date`: Timestamp of when registration occurred

---

## 🚀 How to Run This Application

### Quick Run Guide (For Beginners)

**Before you start, make sure you have:**
- ✓ Java JDK 8+ installed
- ✓ Apache Tomcat 9.0+ installed  
- ✓ MySQL 5.7+ installed and running
- ✓ MySQL JDBC Driver downloaded

### Running the Application - 3 Simple Steps

#### **STEP 1: Setup Database (2 minutes)**
```bash
# Open terminal and run MySQL
mysql -u root -p

# In MySQL prompt, paste these commands:
CREATE DATABASE eventdb;
USE eventdb;

CREATE TABLE participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    usn VARCHAR(20) NOT NULL,
    event VARCHAR(100) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

# Verify it worked:
SHOW TABLES;
EXIT;
```

#### **STEP 2: Setup Application (3 minutes)**

**Option A: Using IDE (Eclipse/IntelliJ)**
1. Import project as "Dynamic Web Project"
2. Add MySQL JDBC JAR to build path
3. Update database password in `DBConnection.java` if needed
4. Right-click project → Run As → Run on Server
5. Select Tomcat server
6. Open browser: `http://localhost:8080/CollegeEventManagement/`

**Option B: Using Command Line**
```bash
# Navigate to project directory
cd "CollegeEventManagement"

# 1. Copy MySQL JDBC driver to Tomcat
cp /path/to/mysql-connector-java-*.jar $CATALINA_HOME/lib/

# 2. Update database password (if you have one)
# Edit: src/com/eventmanagement/db/DBConnection.java
# Change: private static final String DB_PASSWORD = "your_password";

# 3. Compile Java files
mkdir -p build/classes
javac -d build/classes -cp "$CATALINA_HOME/lib/*" \
  src/com/eventmanagement/db/DBConnection.java \
  src/com/eventmanagement/servlet/EventRegisterServlet.java

# 4. Create WAR structure
mkdir -p build/CEMPortal/WEB-INF/classes/com/eventmanagement/db
mkdir -p build/CEMPortal/WEB-INF/classes/com/eventmanagement/servlet
mkdir -p build/CEMPortal/WEB-INF/lib

# 5. Copy all files
cp -r WebContent/* build/CEMPortal/
cp build/classes/com/eventmanagement/db/*.class build/CEMPortal/WEB-INF/classes/com/eventmanagement/db/
cp build/classes/com/eventmanagement/servlet/*.class build/CEMPortal/WEB-INF/classes/com/eventmanagement/servlet/
cp $CATALINA_HOME/lib/mysql-connector-java-*.jar build/CEMPortal/WEB-INF/lib/

# 6. Create WAR file
cd build
jar cf CEMPortal.war CEMPortal/

# 7. Deploy to Tomcat
cp CEMPortal.war $CATALINA_HOME/webapps/

# 8. Start Tomcat
$CATALINA_HOME/bin/startup.sh
```

#### **STEP 3: Access Application (1 minute)**
1. Wait 10-15 seconds for Tomcat to deploy
2. Open browser
3. Go to: `http://localhost:8080/CEMPortal/`
4. You should see the home page! 🎉

### Testing the Application

**Test 1: View Home Page**
- URL: `http://localhost:8080/CEMPortal/`
- Should see 3 events: Tech Fest, Sports Day, Cultural Fest

**Test 2: Register for Event**
1. Click "Register Now" button
2. Fill form:
   - Name: `John Doe`
   - USN: `USN001`
   - Event: `Tech Fest 2026`
3. Click "Register Now"
4. Should redirect to participants page

**Test 3: View Participants**
- Click "View Participants" or go to: `http://localhost:8080/CEMPortal/participants.jsp`
- Should see your registration in the table

**Test 4: Verify Database**
```bash
mysql -u root -p
USE eventdb;
SELECT * FROM participants;
# Should see your test data
```

---

## 🐛 Troubleshooting "How to Run" Issues

### Issue 1: "Can't access http://localhost:8080"
**Solution:**
```bash
# Check if Tomcat is running
ps aux | grep tomcat

# If not running, start it:
$CATALINA_HOME/bin/startup.sh

# Check logs:
tail -50 $CATALINA_HOME/logs/catalina.out
```

### Issue 2: "Database connection failed"
**Solution:**
```bash
# Check MySQL is running
sudo service mysql status

# If not running:
sudo service mysql start

# Test connection:
mysql -u root -p -e "USE eventdb; SHOW TABLES;"
```

### Issue 3: "JDBC Driver not found"
**Solution:**
```bash
# Check if JAR exists in Tomcat lib
ls $CATALINA_HOME/lib/mysql-connector-java-*.jar

# If missing, download from:
# https://dev.mysql.com/downloads/connector/j/
# Then copy to: $CATALINA_HOME/lib/
```

### Issue 4: "HTTP 404 - Not Found"
**Solution:**
```bash
# Check if WAR was deployed
ls $CATALINA_HOME/webapps/ | grep CEMPortal

# Check if folder was extracted
ls $CATALINA_HOME/webapps/CEMPortal/

# If not, wait 10-15 seconds and refresh browser
```

### Issue 5: "Form submission not working"
**Solution:**
1. Open browser console (F12)
2. Check for JavaScript errors
3. Verify database password in `DBConnection.java`
4. Check Tomcat logs: `$CATALINA_HOME/logs/catalina.out`

---

## 📋 Detailed Setup Instructions

### Step 1: Prerequisites

**Install Required Software:**
- Java Development Kit (JDK 8 or higher)
- Apache Tomcat 9.0 or higher
- MySQL Server 5.7 or higher
- MySQL JDBC Driver (mysql-connector-java-5.1.47.jar or latest)

### Step 2: Database Setup

1. Open MySQL Command Line or MySQL Workbench
2. Execute the SQL script:
   ```bash
   mysql -u root -p < database/schema.sql
   ```
3. Verify database was created:
   ```sql
   USE eventdb;
   SHOW TABLES;
   DESC participants;
   ```

### Step 3: MySQL JDBC Driver Installation

1. Download MySQL JDBC Driver from: https://dev.mysql.com/downloads/connector/j/
2. Extract the JAR file
3. Copy to Tomcat lib directory:
   ```bash
   cp mysql-connector-java-x.x.xx.jar $CATALINA_HOME/lib/
   ```
   Replace `$CATALINA_HOME` with your Tomcat installation directory

### Step 4: Configure Database Connection

Edit `src/com/eventmanagement/db/DBConnection.java`:
```java
private static final String DB_USER = "root";
private static final String DB_PASSWORD = ""; // Your MySQL password
```

### Step 5: Compile Java Files

```bash
cd CollegeEventManagement
mkdir -p build/classes
javac -d build/classes -cp ".:$CATALINA_HOME/lib/*" \
    src/com/eventmanagement/db/DBConnection.java \
    src/com/eventmanagement/servlet/EventRegisterServlet.java
```

### Step 6: Create WAR File

1. Create directory structure:
   ```bash
   mkdir -p build/CollegeEventManagement/WEB-INF/classes
   mkdir -p build/CollegeEventManagement/WEB-INF/lib
   mkdir -p build/CollegeEventManagement/css
   ```

2. Copy files:
   ```bash
   cp -r WebContent/* build/CollegeEventManagement/
   cp build/classes/* build/CollegeEventManagement/WEB-INF/classes/
   cp mysql-connector-java-x.x.xx.jar build/CollegeEventManagement/WEB-INF/lib/
   ```

3. Create WAR file:
   ```bash
   cd build
   jar cf CollegeEventManagement.war CollegeEventManagement/
   ```

### Step 7: Deploy to Tomcat

1. Copy WAR file to Tomcat:
   ```bash
   cp build/CollegeEventManagement.war $CATALINA_HOME/webapps/
   ```

2. Start Tomcat:
   ```bash
   $CATALINA_HOME/bin/startup.sh
   ```

3. Access application:
   ```
   http://localhost:8080/CollegeEventManagement/
   ```

---

## 📄 File Descriptions

### 1. **index.jsp** (Home Page)
- **Purpose**: Display event announcements and overview
- **Features**:
  - Shows featured events with dates and venues
  - Links to registration and participant pages
  - Welcome message and how-to instructions
  - Responsive design with CSS styling

### 2. **register.jsp** (Registration Form)
- **Purpose**: Collect event registration details
- **Form Fields**:
  - Name (text input)
  - USN (text input)
  - Event Selection (dropdown)
- **Validation**:
  - Client-side: JavaScript validation
  - Server-side: Servlet validation
- **Submit Action**: POST request to `/register` (EventRegisterServlet)

### 3. **participants.jsp** (Participants List)
- **Purpose**: Display all registered participants
- **Features**:
  - Fetches data from MySQL database
  - Displays in table format with columns:
    - ID
    - Name
    - USN
    - Event
    - Registration Date
  - Shows total participant count
  - Displays message if no participants exist
- **Error Handling**: Shows detailed error messages if database connection fails

### 4. **EventRegisterServlet.java** (Backend Logic)
- **Purpose**: Handle registration form submissions
- **Process Flow**:
  1. Receive form data via POST request
  2. Validate input parameters
  3. Establish database connection
  4. Execute INSERT query using PreparedStatement
  5. Redirect to participants page on success
  6. Forward back to registration page with error on failure
- **Security**: Uses PreparedStatement to prevent SQL injection

### 5. **DBConnection.java** (Database Manager)
- **Purpose**: Manage MySQL database connections
- **Features**:
  - Loads MySQL JDBC Driver
  - Establishes connection to eventdb
  - Returns Connection object
  - Handles exceptions properly
  - Provides method to close connections
- **Configuration**:
  - Driver: com.mysql.jdbc.Driver
  - URL: jdbc:mysql://localhost:3306/eventdb
  - User: root
  - Password: (configure as needed)

### 6. **web.xml** (Deployment Descriptor)
- **Purpose**: Configure servlet mapping and deployment details
- **Contains**:
  - Servlet definition for EventRegisterServlet
  - URL pattern mapping: `/register`
  - Welcome file: `index.jsp`
  - Session configuration (30-minute timeout)

### 7. **style.css** (Styling)
- **Purpose**: Provide clean, student-friendly UI
- **Features**:
  - Gradient background
  - Responsive card layout
  - Form styling with focus states
  - Table styling with alternating row colors
  - Button styling with hover effects
  - Mobile-responsive design
  - Alert/message styling

---

## 🔄 MVC Architecture Explanation

### Model (M)
- **DBConnection.java**: Manages data access
- **Database**: MySQL database (eventdb)

### View (V)
- **index.jsp**: Displays events and welcome message
- **register.jsp**: Shows registration form
- **participants.jsp**: Displays participant data
- **style.css**: Provides styling

### Controller (C)
- **EventRegisterServlet.java**: Handles requests and coordinates between View and Model
- **web.xml**: Routes requests to appropriate servlet

**Data Flow:**
```
User Input (register.jsp) 
    ↓
EventRegisterServlet (processes and validates)
    ↓
DBConnection (executes SQL)
    ↓
MySQL Database (stores data)
    ↓
participants.jsp (displays updated data)
```

---

## 🔐 Security Features

1. **PreparedStatement Usage**
   - Prevents SQL injection attacks
   - Parameters are properly escaped

2. **Input Validation**
   - Client-side validation in JavaScript
   - Server-side validation in servlet
   - Whitespace trimming

3. **Exception Handling**
   - Proper try-catch-finally blocks
   - Resource cleanup in finally blocks
   - User-friendly error messages

4. **Session Management**
   - 30-minute session timeout
   - HTTP-only cookies

---

## 🐛 Common Errors & Solutions

### Error 1: "MySQL JDBC Driver not found"
**Cause:** MySQL Connector JAR not in classpath
**Solution:**
- Download mysql-connector-java-*.jar
- Copy to Tomcat/lib/ directory
- Restart Tomcat

### Error 2: "Database connection failed"
**Cause:** MySQL server not running or wrong credentials
**Solution:**
- Verify MySQL is running: `sudo service mysql status`
- Check credentials in DBConnection.java
- Verify database 'eventdb' exists
- Check firewall settings

### Error 3: "Table 'eventdb.participants' doesn't exist"
**Cause:** SQL script not executed
**Solution:**
- Execute schema.sql: `mysql -u root -p < schema.sql`
- Verify: `USE eventdb; DESC participants;`

### Error 4: "HTTP 404 - Servlet not found"
**Cause:** web.xml not properly configured
**Solution:**
- Check servlet mapping in web.xml
- Verify servlet class path is correct
- Ensure web.xml is in WEB-INF directory
- Restart Tomcat

### Error 5: "Form submission not working"
**Cause:** Form action doesn't match servlet mapping
**Solution:**
- In register.jsp: `<form action="register" method="POST">`
- In web.xml: `<url-pattern>/register</url-pattern>`
- Ensure they match exactly

### Error 6: "JDBC Driver version mismatch"
**Cause:** Old MySQL Connector version incompatible with Tomcat
**Solution:**
- Download latest MySQL JDBC Driver
- Use version 8.0.x or 5.1.47+
- Remove old JAR files

---

## 📝 Testing the Application

### Test Case 1: Register a Participant
1. Go to `http://localhost:8080/CollegeEventManagement/`
2. Click "Register Now" button
3. Fill form:
   - Name: John Doe
   - USN: USN001
   - Event: Tech Fest 2026
4. Submit form
5. Should redirect to participants.jsp
6. Verify data appears in table

### Test Case 2: View Participants
1. Go to participants.jsp
2. Should see table with registered participants
3. Verify all columns display correctly
4. Check registration date is populated

### Test Case 3: Validation Testing
1. Try submitting empty form
2. Should show JavaScript alert
3. Try submitting with empty name
4. Should show validation error

### Test Case 4: Multiple Registrations
1. Register multiple participants
2. Verify all appear in participant list
3. Check participant count increments

---

## 🔧 Tomcat Setup Details

### Finding Tomcat Installation Directory

**Linux/Mac:**
```bash
which catalina.sh
# Or find $CATALINA_HOME
echo $CATALINA_HOME
```

**Windows:**
Check your installation folder (typically C:\Program Files\Apache\Tomcat)

### Common Tomcat Commands

```bash
# Start Tomcat
$CATALINA_HOME/bin/startup.sh

# Stop Tomcat
$CATALINA_HOME/bin/shutdown.sh

# Check Tomcat status
$CATALINA_HOME/bin/catalina.sh version

# View Tomcat logs
tail -f $CATALINA_HOME/logs/catalina.out
```

---

## 📚 Key Concepts for Beginners

### What is Servlet?
- Java class that handles HTTP requests
- Extends HttpServlet
- Has doGet() and doPost() methods
- Processes data and returns response

### What is JSP?
- Java Server Pages
- HTML with embedded Java code
- Server-side processing
- Converted to Servlet by container

### What is JDBC?
- Java Database Connectivity
- API to connect Java with databases
- Uses Connection, Statement, ResultSet
- PreparedStatement for security

### What is PreparedStatement?
- Safer way to execute SQL queries
- Uses ? placeholders for parameters
- Prevents SQL injection
- Pre-compiles SQL statement

### What is MVC?
- Model: Data and business logic
- View: User interface (JSP)
- Controller: Processes requests (Servlet)
- Separates concerns for better organization

---

## 📞 Support & Troubleshooting

### Enable Tomcat Logging
Edit `$CATALINA_HOME/conf/logging.properties` and set:
```
java.util.logging.ConsoleHandler.level = FINE
```

### Debug Database Connection
Add System.out.println() in DBConnection.java:
```java
System.out.println("Connecting to: " + DB_URL);
System.out.println("User: " + DB_USER);
```

### Check MySQL Connection
```bash
mysql -u root -p -e "USE eventdb; SELECT * FROM participants;"
```

### Verify Tomcat is Running
```bash
curl http://localhost:8080/
```

---

## 📖 Additional Resources

- **Apache Tomcat Documentation**: https://tomcat.apache.org/
- **Java Servlet API**: https://docs.oracle.com/javaee/7/
- **MySQL JDBC Driver**: https://dev.mysql.com/doc/connector-j/
- **HTML5 & CSS3**: https://www.w3schools.com/

---

## ✅ Checklist Before Deployment

- [ ] MySQL server installed and running
- [ ] eventdb database created
- [ ] participants table created
- [ ] MySQL JDBC Driver in Tomcat/lib/
- [ ] Java files compiled successfully
- [ ] WAR file created
- [ ] WAR file deployed to webapps/
- [ ] Tomcat started successfully
- [ ] Can access http://localhost:8080/CollegeEventManagement/
- [ ] Can submit registration form
- [ ] Can view participants
- [ ] Database connection working
- [ ] No errors in Tomcat logs

---

## 🎓 Learning Outcomes

After completing this project, you will understand:
1. ✓ How to create dynamic web applications with Java
2. ✓ Servlet lifecycle and request handling
3. ✓ JSP page processing and data display
4. ✓ JDBC for database operations
5. ✓ MVC architecture implementation
6. ✓ HTML forms and validation
7. ✓ CSS styling for web applications
8. ✓ Deployment on Apache Tomcat
9. ✓ SQL queries and database management
10. ✓ Web application security basics

---

**Created:** January 2026
**Version:** 1.0
**Difficulty Level:** Beginner (First-year students)
**Estimated Time to Complete:** 2-3 hours

