-- College Event Management Portal Database
-- Execute this script in MySQL to create the database and tables

-- Create Database
CREATE DATABASE IF NOT EXISTS eventdb;

-- Use the database
USE eventdb;

-- Create Participants Table
CREATE TABLE IF NOT EXISTS participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    usn VARCHAR(20) NOT NULL,
    event VARCHAR(100) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Display table structure
DESC participants;

-- Sample data (Optional - for testing)
-- INSERT INTO participants (name, usn, event) VALUES 
-- ('John Doe', 'USN001', 'Tech Fest'),
-- ('Jane Smith', 'USN002', 'Sports Day'),
-- ('Alex Johnson', 'USN003', 'Tech Fest');
