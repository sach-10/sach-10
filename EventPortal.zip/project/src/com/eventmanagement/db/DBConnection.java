package com.eventmanagement.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection Class - Handles MySQL Database Connection
 * 
 * This class is responsible for:
 * - Loading the MySQL JDBC Driver
 * - Establishing a connection to the database
 * - Returning a Connection object
 * - Handling exceptions properly
 * 
 * Database Details:
 * - Database Name: eventdb
 * - Host: localhost
 * - Port: 3306
 * - Driver: com.mysql.jdbc.Driver (MySQL Connector/J)
 */
public class DBConnection {
    
    // Database configuration constants
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/eventdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = ""; // Set your password here if you have one
    
    /**
     * Method to get database connection
     * 
     * Steps:
     * 1. Load MySQL JDBC Driver
     * 2. Create connection to database using DriverManager
     * 3. Return the Connection object
     * 4. Throw SQLException if connection fails
     * 
     * @return Connection object to the eventdb database
     * @throws SQLException if database connection fails
     */
    public static Connection getConnection() throws SQLException {
        Connection conn = null;
        
        try {
            // Step 1: Load the MySQL JDBC Driver
            // This registers the driver with DriverManager
            Class.forName(JDBC_DRIVER);
            
            // Step 2: Create connection to database
            // DriverManager.getConnection() establishes the connection
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            System.out.println("Database connection established successfully!");
            
        } catch (ClassNotFoundException e) {
            // Exception thrown if MySQL JDBC Driver is not found
            System.out.println("MySQL JDBC Driver not found!");
            System.out.println("Error: " + e.getMessage());
            throw new SQLException("Driver not found: " + e.getMessage());
            
        } catch (SQLException e) {
            // Exception thrown if database connection fails
            System.out.println("Failed to establish database connection!");
            System.out.println("Error: " + e.getMessage());
            throw e;
        }
        
        // Step 3: Return the Connection object
        return conn;
    }
    
    /**
     * Method to close database connection
     * This should be called in finally block or try-with-resources
     * 
     * @param conn Connection object to close
     */
    public static void closeConnection(Connection conn) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Database connection closed!");
            }
        } catch (SQLException e) {
            System.out.println("Error closing connection: " + e.getMessage());
        }
    }
}
