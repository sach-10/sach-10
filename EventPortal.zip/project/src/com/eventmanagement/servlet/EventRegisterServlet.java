package com.eventmanagement.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.eventmanagement.db.DBConnection;

/**
 * EventRegisterServlet - Handles Event Registration
 * 
 * This servlet is responsible for:
 * - Receiving registration form data (POST request)
 * - Validating input data
 * - Inserting data into database using PreparedStatement
 * - Redirecting to participants page after successful registration
 * 
 * URL Pattern: /register
 * Method: POST
 */
public class EventRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * doPost() - Handles POST request for event registration
     * 
     * Process Flow:
     * 1. Get form parameters from request
     * 2. Validate the input data
     * 3. Get database connection
     * 4. Create PreparedStatement with parameterized query
     * 5. Set parameters to prevent SQL injection
     * 6. Execute update
     * 7. Redirect to participants.jsp page
     * 8. Handle exceptions and show error messages
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Step 1: Get form parameters from the request
        String name = request.getParameter("name");
        String usn = request.getParameter("usn");
        String event = request.getParameter("event");
        
        // Step 2: Validate input data (Basic validation)
        if (name == null || name.trim().isEmpty() ||
            usn == null || usn.trim().isEmpty() ||
            event == null || event.trim().isEmpty()) {
            
            // If validation fails, redirect back to registration form with error
            request.setAttribute("errorMsg", "All fields are required!");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }
        
        // Trim whitespace from input
        name = name.trim();
        usn = usn.trim();
        event = event.trim();
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            // Step 3: Get database connection using DBConnection class
            conn = DBConnection.getConnection();
            
            // Step 4: Create PreparedStatement with parameterized query
            // Using ? placeholders prevents SQL injection attacks
            String sql = "INSERT INTO participants (name, usn, event) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            
            // Step 5: Set parameters to replace the ? placeholders
            pstmt.setString(1, name);      // Set name parameter
            pstmt.setString(2, usn);       // Set USN parameter
            pstmt.setString(3, event);     // Set event parameter
            
            // Step 6: Execute the insert query
            int rowsInserted = pstmt.executeUpdate();
            
            // Check if insertion was successful
            if (rowsInserted > 0) {
                System.out.println("Registration successful!");
                System.out.println("Registered: " + name + " for " + event);
                
                // Step 7: Redirect to participants page after successful registration
                response.sendRedirect("participants.jsp");
                
            } else {
                // If no rows were inserted, show error
                request.setAttribute("errorMsg", "Failed to register! Please try again.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }
            
        } catch (SQLException e) {
            // Step 8: Handle database exceptions
            System.out.println("Database Error: " + e.getMessage());
            e.printStackTrace();
            
            request.setAttribute("errorMsg", "Database error: " + e.getMessage());
            try {
                request.getRequestDispatcher("register.jsp").forward(request, response);
            } catch (ServletException | IOException ex) {
                ex.printStackTrace();
            }
            
        } finally {
            // Always close the PreparedStatement and Connection
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    DBConnection.closeConnection(conn);
                }
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    
    /**
     * doGet() - If user tries to access servlet directly via GET request
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Redirect GET requests to registration form
        response.sendRedirect("register.jsp");
    }
}
