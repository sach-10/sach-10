# Quick Start Guide - College Event Management Portal

## ⚡ 5-Minute Setup

### Prerequisites Checklist
- [ ] Java JDK installed (`java -version`)
- [ ] Apache Tomcat installed
- [ ] MySQL installed and running
- [ ] MySQL JDBC Driver downloaded

---

## 🚀 Quick Setup Steps

### Step 1: Create Database (2 minutes)

```bash
# Open MySQL
mysql -u root -p

# Copy-paste this into MySQL:
CREATE DATABASE IF NOT EXISTS eventdb;
USE eventdb;
CREATE TABLE participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    usn VARCHAR(20) NOT NULL,
    event VARCHAR(100) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

# Verify
DESC participants;
EXIT;
```

### Step 2: Add MySQL Driver (1 minute)

```bash
# Copy MySQL JDBC JAR to Tomcat
cp mysql-connector-java-5.1.47.jar $CATALINA_HOME/lib/

# Or on Windows:
# Copy to: C:\Program Files\Apache\Tomcat\lib\
```

### Step 3: Compile Code (1 minute)

```bash
cd CollegeEventManagement
mkdir -p build/classes

javac -d build/classes \
    -cp ".:$CATALINA_HOME/lib/servlet-api.jar:$CATALINA_HOME/lib/mysql-connector-java-5.1.47.jar" \
    src/com/eventmanagement/db/DBConnection.java \
    src/com/eventmanagement/servlet/EventRegisterServlet.java
```

### Step 4: Deploy (1 minute)

```bash
# Create WAR structure
mkdir -p build/CEMPortal/WEB-INF/classes
mkdir -p build/CEMPortal/WEB-INF/lib
mkdir -p build/CEMPortal/css

# Copy files
cp -r WebContent/* build/CEMPortal/
cp build/classes/* build/CEMPortal/WEB-INF/classes/
cp $CATALINA_HOME/lib/mysql-connector-java-5.1.47.jar build/CEMPortal/WEB-INF/lib/

# Create WAR
cd build
jar cf CEMPortal.war CEMPortal/

# Deploy
cp CEMPortal.war $CATALINA_HOME/webapps/
```

### Step 5: Run Application (1 minute)

```bash
# Start Tomcat
$CATALINA_HOME/bin/startup.sh

# Open browser
# http://localhost:8080/CEMPortal/
```

---

## 🧪 Quick Test

1. **Home Page**: Should see event list ✓
2. **Register**: Fill form → Submit ✓
3. **Participants**: Should see your registration ✓

---

## ❌ If Something Goes Wrong

### Problem: "Database connection failed"
```bash
# Check MySQL is running
sudo service mysql status

# If not running, start it:
sudo service mysql start

# Verify eventdb exists:
mysql -u root -p -e "SHOW DATABASES;"
```

### Problem: "HTTP 404 - Not Found"
```bash
# Check Tomcat is running:
ps aux | grep tomcat

# Check logs:
tail -50 $CATALINA_HOME/logs/catalina.out

# Restart Tomcat:
$CATALINA_HOME/bin/shutdown.sh
sleep 3
$CATALINA_HOME/bin/startup.sh
```

### Problem: "Class not found: com.mysql.jdbc.Driver"
```bash
# MySQL JDBC not in classpath
# Verify JAR exists:
ls $CATALINA_HOME/lib/mysql-connector-java-*.jar

# If missing, download and copy it
# Restart Tomcat after adding JAR
```

### Problem: "Port 8080 already in use"
```bash
# Find process using port 8080:
lsof -i :8080

# Kill it:
kill -9 <PID>

# Or change Tomcat port in:
# $CATALINA_HOME/conf/server.xml
# Find: port="8080" and change to port="8081"
```

---

## 📝 Configuration File Locations

| File | Purpose | Location |
|------|---------|----------|
| web.xml | Servlet mapping | `WebContent/WEB-INF/web.xml` |
| style.css | Styling | `WebContent/css/style.css` |
| DBConnection.java | DB config | `src/com/eventmanagement/db/DBConnection.java` |
| schema.sql | Database | `database/schema.sql` |

---

## 🔧 Change Database Credentials

Edit: `src/com/eventmanagement/db/DBConnection.java`

```java
private static final String DB_USER = "root";        // Change this
private static final String DB_PASSWORD = "";         // Add your password
private static final String DB_URL = "jdbc:mysql://localhost:3306/eventdb";
```

Then recompile:
```bash
javac -d build/classes src/com/eventmanagement/db/DBConnection.java
```

---

## 📱 Testing Workflow

```
1. Open http://localhost:8080/CEMPortal/
   ↓
2. Click "Register Event"
   ↓
3. Fill: Name, USN, Event
   ↓
4. Click "Register Now"
   ↓
5. Should redirect to participants page
   ↓
6. Your data should appear in table
```

---

## 🎯 Expected Output

### Successful Registration
```
✓ Form data saved to database
✓ Redirected to participants.jsp
✓ Your registration visible in table
```

### Participants Table Should Show
```
ID | Name      | USN    | Event             | Registration Date
1  | John Doe  | USN001 | Tech Fest 2026    | 2026-01-09 10:30:45
```

---

## 📊 Verify Setup

```bash
# 1. Check database created:
mysql -u root -p -e "USE eventdb; SHOW TABLES;"

# 2. Check table structure:
mysql -u root -p -e "USE eventdb; DESC participants;"

# 3. Check MySQL JAR in Tomcat:
ls -la $CATALINA_HOME/lib/mysql-connector-java-*.jar

# 4. Check if compiled classes exist:
ls -la CollegeEventManagement/build/classes/com/eventmanagement/

# 5. Test Tomcat:
curl -I http://localhost:8080/
```

---

## 🆘 Need More Help?

1. **Check Tomcat Logs**:
   ```bash
   tail -100 $CATALINA_HOME/logs/catalina.out
   ```

2. **Check MySQL Logs**:
   ```bash
   tail -100 /var/log/mysql/error.log
   ```

3. **Verify Connectivity**:
   ```bash
   mysql -h localhost -u root -p -e "SELECT 1;"
   ```

4. **Check Firewall**:
   ```bash
   sudo ufw status
   # Ensure port 8080 and 3306 are open
   ```

---

## ⏱️ Timing Guide

| Step | Time | Notes |
|------|------|-------|
| Create Database | 2 min | Run SQL commands |
| Add JDBC Driver | 1 min | Copy JAR file |
| Compile Code | 1 min | javac command |
| Deploy | 1 min | Copy to webapps |
| Start & Test | 1 min | Access in browser |
| **TOTAL** | **~6 min** | Full setup |

---

## ✅ Success Checklist

After running, verify:

- [ ] MySQL eventdb database exists
- [ ] participants table created
- [ ] MySQL JDBC JAR in Tomcat/lib/
- [ ] Java files compiled
- [ ] WAR deployed to webapps/
- [ ] Tomcat running on port 8080
- [ ] index.jsp loads at http://localhost:8080/CEMPortal/
- [ ] Registration form works
- [ ] Data appears in participants list
- [ ] No errors in browser console

---

## 🎓 Next Steps After Setup

1. **Register Test Data**: Add several participants
2. **Verify Database**: Check data in MySQL
3. **Test Validation**: Try submitting empty form
4. **Explore Code**: Read comments in Java files
5. **Modify Events**: Add your own events in index.jsp
6. **Enhance UI**: Modify style.css
7. **Add Features**: Add search, delete, edit functionality

---

**Quick Start Version:** 1.0  
**Last Updated:** January 2026  
**Difficulty:** Beginner-Friendly ⭐⭐

