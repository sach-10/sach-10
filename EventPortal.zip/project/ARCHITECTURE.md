# System Architecture & Code Explanation

## 🏗️ Application Architecture

### System Overview Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT SIDE (Browser)                    │
│  HTML5 Pages + CSS3 Styling + JavaScript Validation             │
├─────────────────────────────────────────────────────────────────┤
│  index.jsp          register.jsp         participants.jsp       │
│  (Home Page)        (Registration Form)  (View Results)         │
└────────────┬──────────────────┬──────────────────┬──────────────┘
             │ HTTP Requests    │                  │
             ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                 APACHE TOMCAT SERVER                            │
│            (Request Processing & Response)                      │
├─────────────────────────────────────────────────────────────────┤
│ ┌──────────────────────────────────────────────────────────────┐│
│ │  EventRegisterServlet.java (Controller)                     ││
│ │  - Receives POST request from register.jsp                   ││
│ │  - Validates form data                                       ││
│ │  - Calls DBConnection to get database connection             ││
│ │  - Executes INSERT query                                     ││
│ │  - Redirects to participants.jsp on success                 ││
│ └──────────────────────────────────────────────────────────────┘│
│                        │                                        │
│                        ▼                                        │
│ ┌──────────────────────────────────────────────────────────────┐│
│ │  DBConnection.java (Model - Data Access)                    ││
│ │  - Loads MySQL JDBC Driver                                  ││
│ │  - Establishes connection to MySQL                          ││
│ │  - Handles connection cleanup                               ││
│ └──────────────────────────────────────────────────────────────┘│
│                        │                                        │
└────────────────────────┼────────────────────────────────────────┘
                         │ JDBC Connection
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    MYSQL DATABASE                               │
│                  (Data Storage)                                 │
├─────────────────────────────────────────────────────────────────┤
│  Database: eventdb                                              │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ Table: participants                                      │  │
│  │ ┌──────┬─────────────┬────────┬──────────┬─────────────┐│  │
│  │ │ id   │ name        │ usn    │ event    │ reg_date    ││  │
│  │ ├──────┼─────────────┼────────┼──────────┼─────────────┤│  │
│  │ │ 1    │ John Doe    │ USN001 │ Tech Fest│ 2026-01-09  ││  │
│  │ │ 2    │ Jane Smith  │ USN002 │ Sports   │ 2026-01-09  ││  │
│  │ └──────┴─────────────┴────────┴──────────┴─────────────┘│  │
│  └─────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Data Flow Diagram

### User Registration Flow

```
1. USER OPENS BROWSER
   │
   ├─→ http://localhost:8080/CollegeEventManagement/
   │   └─→ index.jsp loads (displays home page with events)
   │
2. USER CLICKS "REGISTER NOW"
   │
   ├─→ Navigates to register.jsp
   │   └─→ Registration form displayed
   │
3. USER FILLS FORM
   │
   ├─→ Name: John Doe
   ├─→ USN: USN001
   ├─→ Event: Tech Fest 2026
   │
4. USER CLICKS "REGISTER NOW" BUTTON
   │
   ├─→ JavaScript validation (client-side)
   │   ├─→ Check if fields are not empty
   │   ├─→ Check if name >= 3 characters
   │   └─→ Check if USN >= 3 characters
   │
   └─→ Form submits POST request to /register
       (form action="register" method="POST")
   │
5. TOMCAT ROUTES REQUEST
   │
   └─→ web.xml maps /register → EventRegisterServlet
   │
6. EVENTREGISTERSERVLET PROCESSES REQUEST
   │
   ├─→ Get parameters: name, usn, event
   ├─→ Server-side validation
   │   ├─→ Trim whitespace
   │   └─→ Check for empty values
   │
   ├─→ Get database connection
   │   └─→ DBConnection.getConnection()
   │       ├─→ Load MySQL JDBC Driver
   │       └─→ DriverManager.getConnection(URL, user, password)
   │
   ├─→ Create PreparedStatement
   │   ├─→ SQL: "INSERT INTO participants (name, usn, event) VALUES (?, ?, ?)"
   │   ├─→ Set parameter 1: name
   │   ├─→ Set parameter 2: usn
   │   └─→ Set parameter 3: event
   │
   ├─→ Execute query
   │   └─→ pstmt.executeUpdate()
   │
   └─→ Check result
       ├─→ Success (rows > 0)
       │   └─→ Close resources
       │   └─→ Redirect to participants.jsp
       │
       └─→ Failure (rows = 0)
           └─→ Forward back to register.jsp with error message
   │
7. DATABASE INSERT
   │
   └─→ MySQL receives INSERT statement
       ├─→ Validate data types
       ├─→ Generate AUTO_INCREMENT id
       ├─→ Insert row into participants table
       └─→ Set registration_date = CURRENT_TIMESTAMP
   │
8. BROWSER REDIRECTS
   │
   └─→ http://localhost:8080/CollegeEventManagement/participants.jsp
   │
9. PARTICIPANTS.JSP LOADS
   │
   ├─→ Get database connection
   ├─→ Execute SELECT query
   ├─→ Fetch all rows from participants table
   │
   └─→ Display results in HTML table
       ├─→ Table headers: ID, Name, USN, Event, Date
       └─→ Table rows: Data from database
   │
10. USER SEES RESULT
    │
    └─→ Their registration appears in the table ✓
```

---

## 💻 Code Walkthrough

### 1. DBConnection.java - Database Connection

```
What it does:
- Manages all database connections
- Loads MySQL JDBC Driver
- Returns Connection object to other classes

Key Methods:
- getConnection(): Creates and returns a connection
- closeConnection(): Closes the connection safely

Why separate class?
- Don't repeat connection code everywhere
- Easy to change database details (one place)
- Good programming practice (reusability)
```

**Code Flow:**
```
1. Class.forName("com.mysql.jdbc.Driver")
   └─→ Loads the MySQL driver into memory

2. DriverManager.getConnection(URL, user, password)
   └─→ Creates connection to MySQL server

3. Return Connection object
   └─→ Other classes can use it to query database

4. closeConnection()
   └─→ Properly closes connection and frees resources
```

---

### 2. EventRegisterServlet.java - Request Handler

```
What it does:
- Receives form submissions from register.jsp
- Validates form data
- Inserts data into database
- Directs user to next page

Why Servlet?
- Standard Java way to handle web requests
- Can process POST/GET requests
- Can access database and send responses
```

**doPost() Method Flow:**

```
INPUT: POST request from register.jsp with:
       - name parameter
       - usn parameter
       - event parameter

STEP 1: Get Form Data
        request.getParameter("name")  → "John Doe"
        request.getParameter("usn")   → "USN001"
        request.getParameter("event") → "Tech Fest"

STEP 2: Validate Data
        if (name == null || name.trim().isEmpty())
            Show error and return

STEP 3: Get Database Connection
        conn = DBConnection.getConnection()

STEP 4: Create Prepared Statement
        String sql = "INSERT INTO participants (name, usn, event) VALUES (?, ?, ?)"
        pstmt = conn.prepareStatement(sql)
        
        Why PreparedStatement?
        - ? placeholders prevent SQL injection
        - Safer than string concatenation

STEP 5: Set Parameters
        pstmt.setString(1, name)    → Replaces first ?
        pstmt.setString(2, usn)     → Replaces second ?
        pstmt.setString(3, event)   → Replaces third ?

STEP 6: Execute Query
        int rowsInserted = pstmt.executeUpdate()

STEP 7: Handle Result
        if (rowsInserted > 0)
            ✓ Success → Redirect to participants.jsp
        else
            ✗ Failed → Show error and stay on register.jsp

STEP 8: Cleanup
        finally {
            Close PreparedStatement
            Close Connection
        }

OUTPUT: Either redirect to participants.jsp or 
        forward back to register.jsp with error
```

---

### 3. JSP Pages - User Interface

#### index.jsp (Home Page)
```
Shows:
- Header with page title
- Navigation bar
- Featured events with details
- Links to register and view participants

Key Elements:
<a href="register.jsp"> → Links to registration form
<a href="participants.jsp"> → Links to participant list
Style from css/style.css → Makes page look good
```

#### register.jsp (Registration Form)
```
Shows:
- Registration form with 3 fields
- JavaScript validation function
- Error messages if validation fails
- Submit button

Form Details:
<form action="register" method="POST">
    ↓
    Submits to EventRegisterServlet (/register)

Validation:
1. JavaScript (before sending to server)
   - Checks if empty
   - Checks minimum length
2. Servlet (on server)
   - Double-checks validation
   - Better security
```

#### participants.jsp (Results Page)
```
Shows:
- Table of all registered participants
- Fetches data from MySQL database
- Displays 5 columns: ID, Name, USN, Event, Date

Database Query:
SELECT id, name, usn, event, registration_date 
FROM participants 
ORDER BY registration_date DESC

Loop through results:
for each row in ResultSet
    Create table row with data
Display in HTML table
```

---

### 4. web.xml - Configuration File

```
What it does:
- Tells Tomcat how to route requests
- Defines which servlets exist
- Maps URL patterns to servlets

Example:
When user goes to /register
    ↓
web.xml looks at <servlet-mapping>
    ↓
Finds that /register maps to EventRegisterServlet
    ↓
Tomcat calls EventRegisterServlet.doPost()
```

**Mapping Configuration:**
```xml
<servlet>
    <servlet-name>EventRegisterServlet</servlet-name>
    <servlet-class>com.eventmanagement.servlet.EventRegisterServlet</servlet-class>
</servlet>

<servlet-mapping>
    <servlet-name>EventRegisterServlet</servlet-name>
    <url-pattern>/register</url-pattern>
</servlet-mapping>

This means:
- Define a servlet called "EventRegisterServlet"
- Map URL "/register" to this servlet
- When user submits form to "register", 
  EventRegisterServlet handles it
```

---

### 5. style.css - Styling

```
Purpose: Make the web pages look attractive

Key Sections:
- body { } → Background and font for all pages
- .card { } → Style for content boxes
- input, select { } → Style for form fields
- table { } → Style for participant table
- .alert { } → Style for error/success messages
- button { } → Style for buttons

Responsive Design:
@media (max-width: 600px)
    Makes pages work on mobile phones too
```

---

## 🔐 Security Explanations

### Why PreparedStatement?

**Unsafe (DON'T DO THIS):**
```java
String sql = "INSERT INTO participants VALUES ('" + name + "', '" + usn + "')";
```
Problem: User could enter: `John'); DROP TABLE participants; --`
Result: SQL injection attack! Database destroyed!

**Safe (DO THIS):**
```java
String sql = "INSERT INTO participants VALUES (?, ?)";
pstmt = conn.prepareStatement(sql);
pstmt.setString(1, name);
pstmt.setString(2, usn);
```
Benefit: SQL structure fixed, data treated as data only

---

### Why Input Validation?

**Client-side validation (register.jsp):**
- Immediate feedback to user
- Reduces unnecessary server requests
- Better user experience

**Server-side validation (servlet):**
- Cannot be bypassed
- Essential for security
- Always validate on server

---

## 🔄 Servlet Lifecycle

```
1. Tomcat starts
   ↓
2. web.xml loaded
   ↓
3. EventRegisterServlet initialized
   ↓
4. User submits form
   ↓
5. doPost() method called
   ↓
6. Form data processed
   ↓
7. Response sent to user
   ↓
8. Servlet waits for next request
   ↓
9. Repeat steps 4-8 for each user request
```

---

## 📝 SQL Queries Explained

### Insert Query
```sql
INSERT INTO participants (name, usn, event) VALUES (?, ?, ?)
```
Explanation:
- INSERT INTO: Add new row
- participants: To this table
- (name, usn, event): These columns
- VALUES (?, ?, ?): With these values (? = placeholder)

### Select Query
```sql
SELECT id, name, usn, event, registration_date 
FROM participants 
ORDER BY registration_date DESC
```
Explanation:
- SELECT: Fetch these columns
- FROM participants: From this table
- ORDER BY registration_date DESC: Newest registrations first

---

## 🧠 Key Programming Concepts

### Classes and Objects
```java
// DBConnection is a class
public class DBConnection {
    // Static method (no object needed to call it)
    public static Connection getConnection() { ... }
}

// Usage: Call without creating object
Connection conn = DBConnection.getConnection();
```

### Methods
```java
// doPost is a method (function)
protected void doPost(HttpServletRequest request, HttpServletResponse response) {
    // Code here runs when POST request received
}
```

### Exception Handling
```java
try {
    // Code that might fail
    conn = DBConnection.getConnection();
} catch (SQLException e) {
    // Code that runs if exception occurs
    System.out.println("Error: " + e.getMessage());
} finally {
    // Code that always runs (cleanup)
    conn.close();
}
```

### PreparedStatement Parameters
```java
pstmt.setString(1, name);    // First ? parameter
pstmt.setString(2, usn);     // Second ? parameter
pstmt.setString(3, event);   // Third ? parameter
```

---

## 📊 Database Transaction Flow

```
1. User submits form
   ↓
2. Servlet receives request
   ↓
3. Connection established
   ↓
4. SQL prepared with placeholders
   ↓
5. Parameters bound to placeholders
   ↓
6. Statement executed
   ↓
7. Rows inserted into database
   ↓
8. Connection committed (auto-commit on)
   ↓
9. Resources closed
   ↓
10. Response sent to user
```

---

## ✅ Verification Checklist

Each component should do:

**DBConnection.java:**
- ✓ Load MySQL driver
- ✓ Create connection to eventdb
- ✓ Return Connection object
- ✓ Close connection safely

**EventRegisterServlet.java:**
- ✓ Receive POST requests
- ✓ Get form parameters
- ✓ Validate input
- ✓ Execute INSERT query
- ✓ Redirect on success
- ✓ Show error on failure

**JSP Pages:**
- ✓ Display HTML correctly
- ✓ Accept user input
- ✓ Show results from database
- ✓ Look good with CSS

**web.xml:**
- ✓ Map /register to servlet
- ✓ Set index.jsp as welcome page
- ✓ Configure session timeout

---

**Version:** 1.0
**Level:** Beginner-Friendly
**Last Updated:** January 2026

