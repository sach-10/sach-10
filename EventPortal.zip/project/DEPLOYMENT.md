# Deployment Guide - Step by Step

## 🐧 Linux Deployment

### Prerequisites for Linux

```bash
# Check Java
java -version

# Check MySQL
mysql --version

# Install if needed:
sudo apt-get update
sudo apt-get install default-jdk
sudo apt-get install mysql-server
sudo apt-get install tomcat9
```

### Full Linux Deployment Steps

**Step 1: Set Environment Variables**
```bash
# Find your Tomcat directory
which catalina.sh

# Or locate it:
find / -name "catalina.sh" 2>/dev/null

# Set environment variable (add to ~/.bashrc or ~/.bash_profile):
export CATALINA_HOME=/usr/share/tomcat9
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64

# Reload bash:
source ~/.bashrc
```

**Step 2: Create Database**
```bash
# Start MySQL
sudo service mysql start

# Connect to MySQL
sudo mysql -u root

# In MySQL prompt:
CREATE DATABASE eventdb;
USE eventdb;

CREATE TABLE participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    usn VARCHAR(20) NOT NULL,
    event VARCHAR(100) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

# Test it:
SHOW DATABASES;
DESC participants;

# Exit
EXIT;
```

**Step 3: Download MySQL JDBC Driver**
```bash
# Option A: Download from MySQL website
cd ~/Downloads
wget https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.49.tar.gz
tar -xzf mysql-connector-java-5.1.49.tar.gz
cd mysql-connector-java-5.1.49
ls mysql-connector-java-5.1.49.jar

# Option B: Or use apt-get
sudo apt-get install libmysql-java
# It will be at: /usr/share/java/mysql-connector-java.jar

# Copy to Tomcat
sudo cp mysql-connector-java-5.1.49.jar $CATALINA_HOME/lib/
sudo chown tomcat:tomcat $CATALINA_HOME/lib/mysql-connector-java-5.1.49.jar
```

**Step 4: Prepare Project**
```bash
cd /path/to/CollegeEventManagement

# Create build directory
mkdir -p build/classes
mkdir -p build/CEMPortal/WEB-INF/classes
mkdir -p build/CEMPortal/WEB-INF/lib

# Compile Java code
javac -d build/classes \
    -cp "$CATALINA_HOME/lib/servlet-api.jar:$CATALINA_HOME/lib/mysql-connector-java-5.1.49.jar" \
    src/com/eventmanagement/db/DBConnection.java \
    src/com/eventmanagement/servlet/EventRegisterServlet.java

# Verify compilation
ls build/classes/com/eventmanagement/db/
ls build/classes/com/eventmanagement/servlet/
```

**Step 5: Create WAR File**
```bash
# Copy resources
cp -r WebContent/* build/CEMPortal/
cp build/classes/com build/CEMPortal/WEB-INF/classes/
cp $CATALINA_HOME/lib/mysql-connector-java-5.1.49.jar build/CEMPortal/WEB-INF/lib/

# Create WAR
cd build
jar cf CEMPortal.war CEMPortal/
ls -lh CEMPortal.war

# Deploy
sudo cp CEMPortal.war $CATALINA_HOME/webapps/
sudo chown tomcat:tomcat $CATALINA_HOME/webapps/CEMPortal.war
```

**Step 6: Start Tomcat**
```bash
# Start Tomcat
sudo service tomcat9 start

# Check status
sudo service tomcat9 status

# View logs
sudo tail -50 $CATALINA_HOME/logs/catalina.out

# Wait for deployment (10-15 seconds)
sleep 15

# Check if application deployed
ls -la $CATALINA_HOME/webapps/ | grep CEMPortal
```

**Step 7: Test Application**
```bash
# Check if Tomcat is listening
netstat -tlnp | grep 8080

# Or curl test:
curl http://localhost:8080/CEMPortal/

# Open in browser:
# http://localhost:8080/CEMPortal/
```

---

## 🪟 Windows Deployment

### Prerequisites for Windows

1. **Install Java:**
   - Download JDK from oracle.com
   - Run installer, note installation path
   - Verify: Open CMD, type `java -version`

2. **Install MySQL:**
   - Download from mysql.com
   - Run installer
   - Note password you set for root user
   - Verify: `mysql --version` in CMD

3. **Download Apache Tomcat:**
   - From tomcat.apache.org
   - Download .zip file
   - Extract to C:\Program Files\Apache\Tomcat

### Full Windows Deployment Steps

**Step 1: Set Environment Variables**
```
1. Right-click "This PC" → Properties
2. Click "Advanced system settings"
3. Click "Environment Variables"
4. Create New System Variables:
   
   CATALINA_HOME = C:\Program Files\Apache\Tomcat
   JAVA_HOME = C:\Program Files\Java\jdk-11.0.11
   
5. Click OK
6. Restart CMD to apply changes
```

**Step 2: Create Database**
```cmd
REM Open Command Prompt as Administrator
REM Start MySQL
net start MySQL80

REM Connect to MySQL
mysql -u root -p
REM Enter password when prompted

REM In MySQL prompt:
CREATE DATABASE eventdb;
USE eventdb;

CREATE TABLE participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    usn VARCHAR(20) NOT NULL,
    event VARCHAR(100) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SHOW DATABASES;
DESC participants;

EXIT;
```

**Step 3: Get MySQL JDBC Driver**
```
1. Download from: https://dev.mysql.com/downloads/connector/j/
2. Extract the ZIP file
3. Find file: mysql-connector-java-5.1.49.jar
4. Copy to: C:\Program Files\Apache\Tomcat\lib\
```

**Step 4: Compile Java Code**
```cmd
cd C:\path\to\CollegeEventManagement

REM Create directories
mkdir build\classes
mkdir build\CEMPortal\WEB-INF\classes
mkdir build\CEMPortal\WEB-INF\lib

REM Compile
javac -d build\classes ^
    -cp "%CATALINA_HOME%\lib\servlet-api.jar;%CATALINA_HOME%\lib\mysql-connector-java-5.1.49.jar" ^
    src\com\eventmanagement\db\DBConnection.java ^
    src\com\eventmanagement\servlet\EventRegisterServlet.java

REM Verify
dir build\classes\com\eventmanagement\db\
dir build\classes\com\eventmanagement\servlet\
```

**Step 5: Create WAR File**
```cmd
REM Copy resources
xcopy WebContent\* build\CEMPortal\ /E /I
xcopy build\classes\com build\CEMPortal\WEB-INF\classes\ /E /I
copy "%CATALINA_HOME%\lib\mysql-connector-java-5.1.49.jar" build\CEMPortal\WEB-INF\lib\

REM Create WAR using jar command
cd build
jar cf CEMPortal.war CEMPortal\
dir CEMPortal.war

REM Deploy
copy CEMPortal.war "%CATALINA_HOME%\webapps\"
```

**Step 6: Start Tomcat**
```cmd
REM Open CMD as Administrator
REM Go to Tomcat bin directory
cd C:\Program Files\Apache\Tomcat\bin

REM Start Tomcat
startup.bat

REM Wait 10-15 seconds for startup
REM Check webapps folder:
dir "%CATALINA_HOME%\webapps"
```

**Step 7: Test Application**
```
1. Open browser
2. Go to: http://localhost:8080/CEMPortal/
3. Should see home page with events
```

---

## 🐛 Troubleshooting by Platform

### Linux Issues

**Port 8080 already in use:**
```bash
# Find process
lsof -i :8080

# Kill it
kill -9 <PID>

# Or use different port
# Edit: $CATALINA_HOME/conf/server.xml
# Find: port="8080" and change to port="8081"
```

**Permission denied errors:**
```bash
# Fix permissions
sudo chown -R tomcat:tomcat $CATALINA_HOME
sudo chmod -R 755 $CATALINA_HOME
```

**MySQL not running:**
```bash
# Start MySQL
sudo service mysql start

# Check status
sudo service mysql status

# View logs
sudo tail /var/log/mysql/error.log
```

**Tomcat not starting:**
```bash
# View logs
tail -100 $CATALINA_HOME/logs/catalina.out

# Check Java
which java
java -version

# Check Tomcat installation
ls $CATALINA_HOME/bin/startup.sh
```

---

### Windows Issues

**Port 8080 in use:**
```cmd
REM Find process using port 8080
netstat -ano | findstr :8080

REM Kill process
taskkill /PID <PID> /F

REM Or change Tomcat port in:
REM C:\Program Files\Apache\Tomcat\conf\server.xml
```

**Java not found:**
```cmd
REM Check Java installation
java -version

REM If not found, add to PATH:
REM Environment Variables → Path → Add C:\Program Files\Java\jdk-11\bin
```

**MySQL not starting:**
```cmd
REM Start MySQL service
net start MySQL80

REM Stop MySQL service
net stop MySQL80

REM Check service status
sc query MySQL80
```

**Tomcat not responding:**
```cmd
REM Stop Tomcat
"%CATALINA_HOME%\bin\shutdown.bat"

REM Wait 5 seconds
timeout /t 5

REM Start Tomcat
"%CATALINA_HOME%\bin\startup.bat"

REM Check logs
type "%CATALINA_HOME%\logs\catalina.out"
```

---

## 🔍 Verification Commands

### Linux Verification
```bash
# 1. Check Java
java -version
echo $JAVA_HOME

# 2. Check MySQL
mysql -u root -p -e "SHOW DATABASES;"

# 3. Check MySQL JDBC
ls -la $CATALINA_HOME/lib/mysql-connector-java-*.jar

# 4. Check Tomcat
$CATALINA_HOME/bin/catalina.sh version

# 5. Check if running
ps aux | grep tomcat

# 6. Test connection
curl -I http://localhost:8080/

# 7. Database test
mysql -u root -p -e "USE eventdb; SELECT * FROM participants LIMIT 1;"
```

### Windows Verification
```cmd
REM 1. Check Java
java -version
echo %JAVA_HOME%

REM 2. Check MySQL
mysql -u root -p -e "SHOW DATABASES;"

REM 3. Check MySQL JDBC
dir "%CATALINA_HOME%\lib\mysql-connector*"

REM 4. Check Tomcat
"%CATALINA_HOME%\bin\catalina.bat" version

REM 5. Check if running
netstat -ano | findstr :8080

REM 6. Test connection
curl http://localhost:8080/

REM 7. Database test
mysql -u root -p -e "USE eventdb; SELECT * FROM participants LIMIT 1;"
```

---

## 📋 Deployment Checklist

### Pre-Deployment
- [ ] Java JDK installed and JAVA_HOME set
- [ ] Tomcat downloaded and CATALINA_HOME set
- [ ] MySQL installed and running
- [ ] MySQL database 'eventdb' created
- [ ] participants table created
- [ ] MySQL JDBC JAR downloaded
- [ ] MySQL JDBC JAR copied to Tomcat/lib/
- [ ] All source files present
- [ ] No syntax errors in code

### Compilation
- [ ] build/classes directory created
- [ ] Java files compile without errors
- [ ] Compiled .class files exist in build/classes
- [ ] No missing imports or class not found errors

### WAR Creation
- [ ] build/CEMPortal directory created
- [ ] WebContent files copied
- [ ] Compiled classes copied to WEB-INF/classes
- [ ] MySQL JDBC copied to WEB-INF/lib
- [ ] WAR file created successfully
- [ ] WAR file has correct structure

### Deployment
- [ ] WAR copied to Tomcat/webapps/
- [ ] Tomcat restarted
- [ ] WAR extracted to CEMPortal folder
- [ ] Application accessible at http://localhost:8080/CEMPortal/
- [ ] No errors in Tomcat logs

### Testing
- [ ] Home page loads
- [ ] Registration form works
- [ ] Data saved to database
- [ ] Participants page shows registered data
- [ ] No JavaScript console errors
- [ ] No Tomcat log errors

---

## 📞 Support Resources

### Online Help
- Apache Tomcat Documentation: https://tomcat.apache.org/
- MySQL Documentation: https://dev.mysql.com/doc/
- Java Servlet API: https://docs.oracle.com/javaee/
- JDBC Tutorial: https://docs.oracle.com/javase/tutorial/jdbc/

### Common Port Numbers
- HTTP: 8080 (Tomcat default)
- MySQL: 3306 (MySQL default)
- HTTPS: 8443 (Tomcat SSL)

### Useful Linux Commands
```bash
grep "ERROR" $CATALINA_HOME/logs/catalina.out
tail -f $CATALINA_HOME/logs/catalina.out
ps aux | grep -E "tomcat|java"
netstat -tlnp | grep java
```

### Useful Windows Commands
```cmd
type "%CATALINA_HOME%\logs\catalina.out"
tasklist | find "java"
netstat -ano | find "java"
```

---

**Version:** 1.0
**Last Updated:** January 2026
**Difficulty:** Beginner-Friendly

